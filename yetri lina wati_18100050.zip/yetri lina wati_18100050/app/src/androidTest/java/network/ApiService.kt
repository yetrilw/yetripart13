package com.informatika.databarang.network
import retrofit2.Call
import retrofit2.http.GET
import ...

interface ApiService {
    @GET( value: "users")
    fun getUser() : Call<List<ResponseUserItem?>>
}